package ismek.webviewkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

   public WebView webArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize
        webArea = findViewById(R.id.webview);

        //Setttings

        webArea.getSettings().setJavaScriptEnabled(true);
        webArea.loadUrl("http://ibb.ist");
    }
}
